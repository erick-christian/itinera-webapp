<?php
/**
 * Created by PhpStorm.
 * User: erickroco
 * Date: 28/02/16
 * Time: 09:25 AM
 */

echo 'csrf_token()';
