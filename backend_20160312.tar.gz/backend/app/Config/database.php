<?php
return array(
    'connections' => array(
        'mysql' => array(
            'driver' => 'mysql',
            'host' => 'localhost',
            'database' => 'itineratms',// Nombre de la base de datos
            'username' => 'itineratms', // Usuario de la base de datos
            'password' => 'S3cr3t4TMS', // Clave del usuario
            'charset' => 'utf8',
            'collation' => 'utf8_unicode_ci',
            'prefix' => '',
        )
    ))

?>